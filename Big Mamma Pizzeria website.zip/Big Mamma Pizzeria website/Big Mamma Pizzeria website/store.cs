﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Big_Mamma_Pizzeria_website
{
    public class store
    {
        public static void start()
        {
            PIZZA pizza1 = new PIZZA("Peperoni & Ost", 99.00, 1);
            PIZZA pizza2 = new PIZZA("Salat Pizza m. Kylling og Dressing", 79.00, 2);
            PIZZA pizza3 = new PIZZA("Amarican Deep pan Pizza", 149.00, 3);
            Console.WriteLine(pizza1);
            Console.WriteLine(pizza2);
            Console.WriteLine(pizza3);
            Console.WriteLine();
            CustomerAdministration customers = new CustomerAdministration();
            CUSTOMER customer1 = new CUSTOMER("Sara", "Ishøj", "42213157");
            CUSTOMER customer2 = new CUSTOMER("Amina", "Vallensbæk", "57496235");
            CUSTOMER customer3 = new CUSTOMER("Samira", "Høje Taastrup", "18523697");
            Console.WriteLine();
            customers.AddCustommer(customer1);
            customers.AddCustommer(customer2);
            customers.AddCustommer(customer3);
            customers.PrintCustomers();
            Console.WriteLine();
            ORDER order1 = new ORDER("Amina", "Salat Pizza m. Kylling og Dressing", "Vallensbæk");
            ORDER order2 = new ORDER("Samira", "Amarican Deep pan Pizza", "Høje Taastrup");
            ORDER order3 = new ORDER("Sara", "Salat Pizza m. Kylling og Dressing", "Ishøj");
            Console.WriteLine(order1);
            Console.WriteLine(order2);
            Console.WriteLine(order3);
        }

    }
}
