﻿using System.Windows.Markup;

namespace Big_Mamma_Pizzeria_website
{

    public class CUSTOMER
    {
        //instance field//
        private string _name;
        private string _Address;
        private string _Number; 
        
       //properties
        public string Name { get { return _name; } set { _name = value; } }
        public string Address { get { return _Address; } set { _Address = value;  } }
        public string Number { get { return _Number; } set { _Number = value; } }

        public CUSTOMER(string name, string Address, string Number)
        {
            _name = name;
            _Address = Address;
            _Number = Number;
        }

        public override string ToString()
        {
            return "Kunden hedder = " + _name + ", hendes ordre skal levere til = " + _Address + ", hendes Tlf. nummer er = " + _Number;
        }


    }

}
