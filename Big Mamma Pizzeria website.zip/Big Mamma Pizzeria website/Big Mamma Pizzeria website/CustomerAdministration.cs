﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Big_Mamma_Pizzeria_website
{
    public class CustomerAdministration
    {
        private List<CUSTOMER> _customer = new List<CUSTOMER>();

        public void AddCustommer(CUSTOMER newcustomer)
        {
            _customer.Add(newcustomer);
        }

        public void DeleteCustomer(CUSTOMER removeCustomer)
        {
            _customer.Remove(removeCustomer);
        }

        public void UpdateCustomer(CUSTOMER updateCustomer, string name, string address, string number)
        {
            updateCustomer.Name = name;
            updateCustomer.Address = address;
            updateCustomer.Number = number;    
        }

        public void PrintCustomers()
        {
            foreach (var customer in _customer)
            {
                Console.WriteLine(customer);
            }
        }

        public void FindCustomer(string name)
        {
            foreach (var customer in _customer) 
            { if (customer.Name == name)
                {
                   Console.WriteLine(customer);
                }        
            }
        }
    }
}
