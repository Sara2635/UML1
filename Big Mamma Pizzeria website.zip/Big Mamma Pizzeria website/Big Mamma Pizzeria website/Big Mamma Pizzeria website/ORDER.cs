﻿namespace Big_Mamma_Pizzeria_website
{
    public class ORDER
    {
        private string _name;
        private string _order;
        private string _address;

        public ORDER(string name, string order, string address)
        {
            _name = name;
            _order = order;
            _address = address;
        }

        public override string ToString() //metode
        {
            return "Kunden hedder = " + _name + ", kunden har valgt at købe = " + _order + ", ordren skal leveres til = " + _address;

        }
    }
}
