﻿namespace Big_Mamma_Pizzeria_website
{

    public class CUSTOMER
    {
        private string _name;
        private string _Address;
        private object _Number; 


        public CUSTOMER(string name, string Address, object Number)
        {
            _name = name;
            _Address = Address;
            _Number = Number;
        }

        public override string ToString()
        {
            return "Kunden hedder = " + _name + ", hendes ordre skal levere til = " + _Address + ", hendes Tlf. nummer er = " + _Number;
        }

    }

}
