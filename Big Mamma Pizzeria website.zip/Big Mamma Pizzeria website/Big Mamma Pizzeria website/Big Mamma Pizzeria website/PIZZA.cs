﻿namespace Big_Mamma_Pizzeria_website
{
    public class PIZZA //instance field
    {
        private string _name;
        private double _price;
        public int _pizzaNumber;

        public PIZZA(string name, double price, int number) //constructer
        {
            _name = name;
            _price = price;
            _pizzaNumber = number;
        }

        public override string ToString() //metode
        {
            return "Navnet på Pizza'en er = " + _name + ", Prisen på Pizza'en er = " + _price + "kr., Pizza nummeret er = " + _pizzaNumber;

        }
    }
}

